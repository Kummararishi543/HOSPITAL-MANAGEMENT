# Hospital-Management
This is the frontend part of my website

This website is built using the basic technologies:
    1. HTML
    2. CSS and 
    3. Javascript